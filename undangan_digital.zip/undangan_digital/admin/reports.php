<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth.php';

// Check admin authentication
if (!isAdminLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Get filter parameters
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$report_type = $_GET['report_type'] ?? 'overview';

// Generate reports
$reports = generateReports($start_date, $end_date, $report_type);

function generateReports($start_date, $end_date, $type) {
    global $conn;
    
    $reports = [];
    
    switch($type) {
        case 'guests':
            $reports = getGuestReport($start_date, $end_date);
            break;
        case 'payments':
            $reports = getPaymentReport($start_date, $end_date);
            break;
        case 'messages':
            $reports = getMessageReport($start_date, $end_date);
            break;
        case 'overview':
        default:
            $reports = getOverviewReport($start_date, $end_date);
            break;
    }
    
    return $reports;
}

function getOverviewReport($start_date, $end_date) {
    global $conn;
    
    $report = [
        'guests' => [
            'total' => 0,
            'confirmed' => 0,
            'pending' => 0,
            'attended' => 0
        ],
        'payments' => [
            'total_amount' => 0,
            'total_transactions' => 0,
            'average_amount' => 0
        ],
        'messages' => [
            'total' => 0,
            'with_likes' => 0
        ],
        'timeline' => []
    ];
    
    // Get guest statistics
    $sql = "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN attendance_status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
        SUM(CASE WHEN attendance_status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN attended = 1 THEN 1 ELSE 0 END) as attended
        FROM guests 
        WHERE created_at BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    $guest_stats = $result->fetch_assoc();
    
    $report['guests'] = $guest_stats;
    
    // Get payment statistics
    $sql = "SELECT 
        COUNT(*) as total_transactions,
        SUM(amount) as total_amount,
        AVG(amount) as average_amount
        FROM payments 
        WHERE payment_status = 'success' 
        AND created_at BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    $payment_stats = $result->fetch_assoc();
    
    $report['payments'] = $payment_stats;
    
    // Get message statistics
    $sql = "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN like_count > 0 THEN 1 ELSE 0 END) as with_likes
        FROM messages 
        WHERE created_at BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    $message_stats = $result->fetch_assoc();
    
    $report['messages'] = $message_stats;
    
    // Get timeline data (last 7 days)
    $sql = "SELECT 
        DATE(created_at) as date,
        COUNT(*) as guest_count,
        SUM(CASE WHEN attendance_status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_count,
        COALESCE(SUM(p.amount), 0) as payment_amount,
        COUNT(DISTINCT p.id) as payment_count
        FROM guests g
        LEFT JOIN payments p ON DATE(p.created_at) = DATE(g.created_at) AND p.payment_status = 'success'
        WHERE g.created_at BETWEEN DATE_SUB(?, INTERVAL 7 DAY) AND ?
        GROUP BY DATE(g.created_at)
        ORDER BY date DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $end_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['timeline'][] = $row;
    }
    
    return $report;
}

function getGuestReport($start_date, $end_date) {
    global $conn;
    
    $report = [
        'summary' => [],
        'details' => [],
        'groups' => []
    ];
    
    // Get guest summary by group
    $sql = "SELECT 
        guest_group,
        COUNT(*) as total,
        SUM(CASE WHEN attendance_status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
        SUM(CASE WHEN attended = 1 THEN 1 ELSE 0 END) as attended
        FROM guests 
        WHERE created_at BETWEEN ? AND ?
        GROUP BY guest_group
        ORDER BY total DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['groups'][] = $row;
    }
    
    // Get guest details
    $sql = "SELECT 
        g.*,
        COALESCE(p.total_amount, 0) as gift_amount,
        COALESCE(p.payment_method, '-') as payment_method
        FROM guests g
        LEFT JOIN (
            SELECT guest_id, SUM(amount) as total_amount, MAX(payment_method) as payment_method
            FROM payments 
            WHERE payment_status = 'success'
            GROUP BY guest_id
        ) p ON g.id = p.guest_id
        WHERE g.created_at BETWEEN ? AND ?
        ORDER BY g.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['details'][] = $row;
    }
    
    return $report;
}

function getPaymentReport($start_date, $end_date) {
    global $conn;
    
    $report = [
        'summary' => [],
        'transactions' => [],
        'methods' => []
    ];
    
    // Get payment summary
    $sql = "SELECT 
        DATE(created_at) as date,
        COUNT(*) as transaction_count,
        SUM(amount) as total_amount,
        AVG(amount) as average_amount
        FROM payments 
        WHERE payment_status = 'success' 
        AND created_at BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY date DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['summary'][] = $row;
    }
    
    // Get transactions
    $sql = "SELECT 
        p.*,
        g.name as guest_name,
        g.phone as guest_phone
        FROM payments p
        LEFT JOIN guests g ON p.guest_id = g.id
        WHERE p.payment_status = 'success' 
        AND p.created_at BETWEEN ? AND ?
        ORDER BY p.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['transactions'][] = $row;
    }
    
    // Get payment methods distribution
    $sql = "SELECT 
        payment_method,
        COUNT(*) as transaction_count,
        SUM(amount) as total_amount
        FROM payments 
        WHERE payment_status = 'success' 
        AND created_at BETWEEN ? AND ?
        GROUP BY payment_method
        ORDER BY total_amount DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['methods'][] = $row;
    }
    
    return $report;
}

function getMessageReport($start_date, $end_date) {
    global $conn;
    
    $report = [
        'summary' => [],
        'messages' => [],
        'top_liked' => []
    ];
    
    // Get message summary
    $sql = "SELECT 
        DATE(created_at) as date,
        COUNT(*) as message_count,
        SUM(like_count) as total_likes,
        AVG(like_count) as average_likes
        FROM messages 
        WHERE created_at BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY date DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['summary'][] = $row;
    }
    
    // Get all messages
    $sql = "SELECT 
        m.*,
        g.name as guest_name,
        g.relation as guest_relation
        FROM messages m
        LEFT JOIN guests g ON m.guest_id = g.id
        WHERE m.created_at BETWEEN ? AND ?
        ORDER BY m.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['messages'][] = $row;
    }
    
    // Get top liked messages
    $sql = "SELECT 
        m.*,
        g.name as guest_name
        FROM messages m
        LEFT JOIN guests g ON m.guest_id = g.id
        WHERE m.created_at BETWEEN ? AND ?
        ORDER BY m.like_count DESC
        LIMIT 10";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while($row = $result->fetch_assoc()) {
        $report['top_liked'][] = $row;
    }
    
    return $report;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="admin-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="content-header">
                <h1><i class="fas fa-chart-line"></i> Laporan & Analitik</h1>
                <div class="header-actions">
                    <button class="btn btn-print" onclick="printReport()">
                        <i class="fas fa-print"></i> Cetak
                    </button>
                    <button class="btn btn-export" onclick="exportReport()">
                        <i class="fas fa-file-export"></i> Export
                    </button>
                </div>
            </div>
            
            <!-- Report Filters -->
            <div class="card report-filters">
                <form method="GET" class="filter-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="report_type">Jenis Laporan:</label>
                            <select name="report_type" id="report_type" onchange="this.form.submit()">
                                <option value="overview" <?= $report_type == 'overview' ? 'selected' : '' ?>>Overview</option>
                                <option value="guests" <?= $report_type == 'guests' ? 'selected' : '' ?>>Data Tamu</option>
                                <option value="payments" <?= $report_type == 'payments' ? 'selected' : '' ?>>Pembayaran</option>
                                <option value="messages" <?= $report_type == 'messages' ? 'selected' : '' ?>>Ucapan</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="start_date">Dari Tanggal:</label>
                            <input type="date" 
                                   name="start_date" 
                                   id="start_date" 
                                   value="<?= $start_date ?>"
                                   onchange="this.form.submit()">
                        </div>
                        
                        <div class="form-group">
                            <label for="end_date">Sampai Tanggal:</label>
                            <input type="date" 
                                   name="end_date" 
                                   id="end_date" 
                                   value="<?= $end_date ?>"
                                   onchange="this.form.submit()">
                        </div>
                        
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Filter
                            </button>
                            <a href="reports.php" class="btn btn-secondary">
                                <i class="fas fa-redo"></i> Reset
                            </a>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Report Content -->
            <div class="report-content" id="reportContent">
                <?php if($report_type == 'overview'): ?>
                    <!-- Overview Report -->
                    <div class="overview-report">
                        <!-- Summary Cards -->
                        <div class="summary-cards">
                            <div class="summary-card">
                                <div class="card-icon bg-primary">
                                    <i class="fas fa-users"></i>
                                </div>
                                <div class="card-content">
                                    <h3><?= number_format($reports['guests']['total']) ?></h3>
                                    <p>Total Tamu</p>
                                </div>
                                <div class="card-details">
                                    <span><?= number_format($reports['guests']['confirmed']) ?> Konfirmasi</span>
                                    <span><?= number_format($reports['guests']['attended']) ?> Hadir</span>
                                </div>
                            </div>
                            
                            <div class="summary-card">
                                <div class="card-icon bg-success">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                                <div class="card-content">
                                    <h3>Rp <?= number_format($reports['payments']['total_amount'], 0, ',', '.') ?></h3>
                                    <p>Total Hadiah</p>
                                </div>
                                <div class="card-details">
                                    <span><?= number_format($reports['payments']['total_transactions']) ?> Transaksi</span>
                                    <span>Rp <?= number_format($reports['payments']['average_amount'], 0, ',', '.') ?> Rata-rata</span>
                                </div>
                            </div>
                            
                            <div class="summary-card">
                                <div class="card-icon bg-info">
                                    <i class="fas fa-comments"></i>
                                </div>
                                <div class="card-content">
                                    <h3><?= number_format($reports['messages']['total']) ?></h3>
                                    <p>Total Ucapan</p>
                                </div>
                                <div class="card-details">
                                    <span><?= number_format($reports['messages']['with_likes']) ?> Disukai</span>
                                    <span><?= number_format($reports['messages']['total'] > 0 ? ($reports['messages']['with_likes'] / $reports['messages']['total'] * 100) : 0, 1) ?>% Engagement</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Charts -->
                        <div class="chart-row">
                            <div class="chart-card">
                                <h4>Statistik Tamu (7 Hari Terakhir)</h4>
                                <canvas id="guestChart"></canvas>
                            </div>
                            <div class="chart-card">
                                <h4>Distribusi Pembayaran</h4>
                                <canvas id="paymentChart"></canvas>
                            </div>
                        </div>
                        
                        <!-- Timeline Data -->
                        <div class="table-card">
                            <h4>Data Timeline</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>Tamu Baru</th>
                                            <th>Konfirmasi</th>
                                            <th>Pembayaran</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($reports['timeline'] as $day): ?>
                                        <tr>
                                            <td><?= date('d M Y', strtotime($day['date'])) ?></td>
                                            <td><?= number_format($day['guest_count']) ?></td>
                                            <td><?= number_format($day['confirmed_count']) ?></td>
                                            <td>Rp <?= number_format($day['payment_amount'], 0, ',', '.') ?></td>
                                            <td><?= number_format($day['payment_count']) ?> transaksi</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif($report_type == 'guests'): ?>
                    <!-- Guest Report -->
                    <div class="guest-report">
                        <!-- Group Summary -->
                        <div class="table-card">
                            <h4>Statistik Tamu per Grup</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Grup Tamu</th>
                                            <th>Total</th>
                                            <th>Konfirmasi</th>
                                            <th>Hadir</th>
                                            <th>% Konfirmasi</th>
                                            <th>% Kehadiran</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($reports['groups'] as $group): ?>
                                        <?php 
                                        $confirmation_rate = $group['total'] > 0 ? ($group['confirmed'] / $group['total'] * 100) : 0;
                                        $attendance_rate = $group['confirmed'] > 0 ? ($group['attended'] / $group['confirmed'] * 100) : 0;
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($group['guest_group']) ?></td>
                                            <td><?= number_format($group['total']) ?></td>
                                            <td><?= number_format($group['confirmed']) ?></td>
                                            <td><?= number_format($group['attended']) ?></td>
                                            <td><?= number_format($confirmation_rate, 1) ?>%</td>
                                            <td><?= number_format($attendance_rate, 1) ?>%</td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Guest Details -->
                        <div class="table-card">
                            <h4>Detail Tamu</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Telepon</th>
                                            <th>Grup</th>
                                            <th>Status</th>
                                            <th>Kehadiran</th>
                                            <th>Hadiah</th>
                                            <th>Metode</th>
                                            <th>Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($reports['details'] as $guest): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($guest['name']) ?></td>
                                            <td><?= htmlspecialchars($guest['phone']) ?></td>
                                            <td><?= htmlspecialchars($guest['guest_group']) ?></td>
                                            <td>
                                                <span class="status-badge status-<?= $guest['attendance_status'] ?>">
                                                    <?= $guest['attendance_status'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if($guest['attended']): ?>
                                                <span class="badge bg-success">Hadir</span>
                                                <?php else: ?>
                                                <span class="badge bg-secondary">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>Rp <?= number_format($guest['gift_amount'], 0, ',', '.') ?></td>
                                            <td><?= htmlspecialchars($guest['payment_method']) ?></td>
                                            <td><?= date('d/m/Y', strtotime($guest['created_at'])) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif($report_type == 'payments'): ?>
                    <!-- Payment Report -->
                    <div class="payment-report">
                        <!-- Summary -->
                        <div class="summary-cards">
                            <div class="summary-card">
                                <h4>Total Transaksi</h4>
                                <h2><?= number_format(array_sum(array_column($reports['summary'], 'transaction_count'))) ?></h2>
                            </div>
                            <div class="summary-card">
                                <h4>Total Nilai</h4>
                                <h2>Rp <?= number_format(array_sum(array_column($reports['summary'], 'total_amount')), 0, ',', '.') ?></h2>
                            </div>
                            <div class="summary-card">
                                <h4>Rata-rata</h4>
                                <h2>Rp <?= number_format($reports['summary'][0]['average_amount'] ?? 0, 0, ',', '.') ?></h2>
                            </div>
                        </div>
                        
                        <!-- Transaction Details -->
                        <div class="table-card">
                            <h4>Detail Transaksi</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama</th>
                                            <th>Telepon</th>
                                            <th>Jumlah</th>
                                            <th>Metode</th>
                                            <th>Status</th>
                                            <th>Tanggal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($reports['transactions'] as $payment): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($payment['transaction_id']) ?></td>
                                            <td><?= htmlspecialchars($payment['guest_name']) ?></td>
                                            <td><?= htmlspecialchars($payment['guest_phone']) ?></td>
                                            <td>Rp <?= number_format($payment['amount'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?= htmlspecialchars($payment['payment_method']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="status-badge status-<?= $payment['payment_status'] ?>">
                                                    <?= $payment['payment_status'] ?>
                                                </span>
                                            </td>
                                            <td><?= date('d/m/Y H:i', strtotime($payment['created_at'])) ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-view" 
                                                        onclick="viewPayment('<?= $payment['id'] ?>')">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- Payment Methods -->
                        <div class="table-card">
                            <h4>Distribusi Metode Pembayaran</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Metode</th>
                                            <th>Transaksi</th>
                                            <th>Total Nilai</th>
                                            <th>% dari Total</th>
                                            <th>Rata-rata</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $total_all = array_sum(array_column($reports['methods'], 'total_amount'));
                                        foreach($reports['methods'] as $method): 
                                            $percentage = $total_all > 0 ? ($method['total_amount'] / $total_all * 100) : 0;
                                            $average = $method['transaction_count'] > 0 ? ($method['total_amount'] / $method['transaction_count']) : 0;
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($method['payment_method']) ?></td>
                                            <td><?= number_format($method['transaction_count']) ?></td>
                                            <td>Rp <?= number_format($method['total_amount'], 0, ',', '.') ?></td>
                                            <td><?= number_format($percentage, 1) ?>%</td>
                                            <td>Rp <?= number_format($average, 0, ',', '.') ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif($report_type == 'messages'): ?>
                    <!-- Message Report -->
                    <div class="message-report">
                        <!-- Summary -->
                        <div class="summary-cards">
                            <div class="summary-card">
                                <h4>Total Ucapan</h4>
                                <h2><?= number_format($reports['summary'][0]['message_count'] ?? 0) ?></h2>
                            </div>
                            <div class="summary-card">
                                <h4>Total Suka</h4>
                                <h2><?= number_format($reports['summary'][0]['total_likes'] ?? 0) ?></h2>
                            </div>
                            <div class="summary-card">
                                <h4>Rata-rata Suka</h4>
                                <h2><?= number_format($reports['summary'][0]['average_likes'] ?? 0, 1) ?></h2>
                            </div>
                        </div>
                        
                        <!-- Top Liked Messages -->
                        <div class="table-card">
                            <h4>Ucapan Paling Disukai</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Pengirim</th>
                                            <th>Ucapan</th>
                                            <th>Suka</th>
                                            <th>Tanggal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($reports['top_liked'] as $message): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($message['guest_name']) ?></td>
                                            <td class="message-preview">
                                                <?= htmlspecialchars(substr($message['message'], 0, 100)) ?>...
                                            </td>
                                            <td>
                                                <span class="badge bg-warning">
                                                    <i class="fas fa-heart"></i> <?= number_format($message['like_count']) ?>
                                                </span>
                                            </td>
                                            <td><?= date('d/m/Y', strtotime($message['created_at'])) ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-view" 
                                                        onclick="viewMessage('<?= $message['id'] ?>')">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <!-- All Messages -->
                        <div class="table-card">
                            <h4>Semua Ucapan</h4>
                            <div class="table-responsive">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Pengirim</th>
                                            <th>Hubungan</th>
                                            <th>Ucapan</th>
                                            <th>Suka</th>
                                            <th>Privasi</th>
                                            <th>Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($reports['messages'] as $message): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($message['guest_name']) ?></td>
                                            <td><?= htmlspecialchars($message['guest_relation']) ?></td>
                                            <td class="message-preview">
                                                <?= htmlspecialchars(substr($message['message'], 0, 80)) ?>...
                                            </td>
                                            <td><?= number_format($message['like_count']) ?></td>
                                            <td>
                                                <?php if($message['privacy'] == 'public'): ?>
                                                <span class="badge bg-success">Publik</span>
                                                <?php else: ?>
                                                <span class="badge bg-secondary">Pribadi</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= date('d/m/Y H:i', strtotime($message['created_at'])) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
    // Initialize charts for overview report
    <?php if($report_type == 'overview'): ?>
    document.addEventListener('DOMContentLoaded', function() {
        // Guest Chart
        const guestCtx = document.getElementById('guestChart').getContext('2d');
        const guestChart = new Chart(guestCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($reports['timeline'], 'date')) ?>,
                datasets: [{
                    label: 'Tamu Baru',
                    data: <?= json_encode(array_column($reports['timeline'], 'guest_count')) ?>,
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Konfirmasi',
                    data: <?= json_encode(array_column($reports['timeline'], 'confirmed_count')) ?>,
                    borderColor: '#2ecc71',
                    backgroundColor: 'rgba(46, 204, 113, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
        
        // Payment Chart
        const paymentCtx = document.getElementById('paymentChart').getContext('2d');
        const paymentChart = new Chart(paymentCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($reports['timeline'], 'date')) ?>,
                datasets: [{
                    label: 'Total Pembayaran',
                    data: <?= json_encode(array_column($reports['timeline'], 'payment_amount')) ?>,
                    backgroundColor: '#9b59b6',
                    borderColor: '#8e44ad',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Total: Rp ' + context.raw.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });
    });
    <?php endif; ?>
    
    function printReport() {
        const printContent = document.getElementById('reportContent').innerHTML;
        const originalContent = document.body.innerHTML;
        
        document.body.innerHTML = `
            <html>
                <head>
                    <title>Laporan Undangan Digital</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        h1, h2, h3, h4 { color: #333; }
                        .table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        .table th { background-color: #f4f4f4; }
                        .summary-card { border: 1px solid #ddd; padding: 15px; margin: 10px 0; }
                        .badge { padding: 2px 8px; border-radius: 4px; font-size: 12px; }
                        .bg-success { background-color: #d4edda; color: #155724; }
                        .bg-info { background-color: #d1ecf1; color: #0c5460; }
                        .bg-warning { background-color: #fff3cd; color: #856404; }
                        @media print {
                            .no-print { display: none; }
                        }
                    </style>
                </head>
                <body>
                    <h1>Laporan Undangan Digital</h1>
                    <p>Periode: <?= date('d F Y', strtotime($start_date)) ?> - <?= date('d F Y', strtotime($end_date)) ?></p>
                    <p>Jenis Laporan: <?= ucfirst($report_type) ?></p>
                    ${printContent}
                    <div class="no-print">
                        <button onclick="window.print()">Cetak</button>
                        <button onclick="document.body.innerHTML = originalContent">Kembali</button>
                    </div>
                </body>
            </html>
        `;
        
        window.print();
        document.body.innerHTML = originalContent;
    }
    
    function exportReport() {
        // Create CSV content
        let csvContent = "data:text/csv;charset=utf-8,";
        
        <?php if($report_type == 'guests'): ?>
            csvContent += "Nama,Telepon,Grup,Status,Kehadiran,Hadiah,Metode,Tanggal\n";
            <?php foreach($reports['details'] as $guest): ?>
                csvContent += "<?= addslashes($guest['name']) ?>,<?= $guest['phone'] ?>,<?= addslashes($guest['guest_group']) ?>,<?= $guest['attendance_status'] ?>,<?= $guest['attended'] ? 'Hadir' : '-' ?>,<?= $guest['gift_amount'] ?>,<?= addslashes($guest['payment_method']) ?>,<?= date('d/m/Y', strtotime($guest['created_at'])) ?>\n";
            <?php endforeach; ?>
        <?php elseif($report_type == 'payments'): ?>
            csvContent += "ID Transaksi,Nama,Telepon,Jumlah,Metode,Status,Tanggal\n";
            <?php foreach($reports['transactions'] as $payment): ?>
                csvContent += "<?= $payment['transaction_id'] ?>,<?= addslashes($payment['guest_name']) ?>,<?= $payment['guest_phone'] ?>,<?= $payment['amount'] ?>,<?= addslashes($payment['payment_method']) ?>,<?= $payment['payment_status'] ?>,<?= date('d/m/Y H:i', strtotime($payment['created_at'])) ?>\n";
            <?php endforeach; ?>
        <?php elseif($report_type == 'messages'): ?>
            csvContent += "Pengirim,Hubungan,Ucapan,Suka,Privasi,Tanggal\n";
            <?php foreach($reports['messages'] as $message): ?>
                csvContent += "<?= addslashes($message['guest_name']) ?>,<?= addslashes($message['guest_relation']) ?>,<?= addslashes($message['message']) ?>,<?= $message['like_count'] ?>,<?= $message['privacy'] ?>,<?= date('d/m/Y H:i', strtotime($message['created_at'])) ?>\n";
            <?php endforeach; ?>
        <?php endif; ?>
        
        // Create download link
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "laporan_<?= $report_type ?>_<?= date('Ymd') ?>.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    function viewPayment(paymentId) {
        window.open(`payment_detail.php?id=${paymentId}`, '_blank');
    }
    
    function viewMessage(messageId) {
        window.open(`message_detail.php?id=${messageId}`, '_blank');
    }
    </script>
</body>
</html>