<?php
/**
 * DATABASE CONFIGURATION - XAMPP DEFAULT
 * Setting untuk XAMPP localhost
 */

class DatabaseConfig {
    // ========== DATABASE SETTINGS (XAMPP Default) ==========
    const DB_HOST = 'localhost';      // XAMPP default
    const DB_PORT = '3306';           // XAMPP default port
    const DB_NAME = 'undangan_digital'; // Database name
    const DB_USER = 'root';           // XAMPP default username √
    const DB_PASS = '';               // XAMPP default (kosong) √

    /**
     * Check if running on localhost
     */
    public static function isLocalhost() {
        $whitelist = array('127.0.0.1', '::1', 'localhost');
        $remote_addr = $_SERVER['REMOTE_ADDR'] ?? '';
        $server_name = $_SERVER['SERVER_NAME'] ?? '';
        $http_host = $_SERVER['HTTP_HOST'] ?? '';
        
        return in_array($remote_addr, $whitelist) || 
               in_array($server_name, $whitelist) ||
               strpos($http_host, 'localhost') !== false ||
               strpos($http_host, '127.0.0.1') !== false;
    }
    
    /**
     * Check debug mode
     */
    public static function isDebugMode() {
        return defined('DEBUG_MODE') ? DEBUG_MODE : self::DEBUG_MODE;
    }
    
    // ========== SITE SETTINGS ==========
    const SITE_NAME = 'Undangan Digital Premium';
    const TIMEZONE = 'Asia/Jakarta';
    const DEBUG_MODE = true; // TRUE untuk debugging
    
    // ========== SECURITY SETTINGS ==========
    const ENCRYPTION_KEY = 'wedding_digital_secret_key_2025';
    const JWT_SECRET = 'jwt_wedding_secret_2025';
    
    // ========== UPLOAD SETTINGS ==========
    const MAX_UPLOAD_SIZE = 5242880; // 5MB
    
    // ========== WHATSAPP SETTINGS ==========
    const WHATSAPP_NUMBER = '6281234567890';
    const WHATSAPP_MESSAGE = 'Halo, saya melihat undangan pernikahan Anda';
    
    // ========== QRIS SETTINGS ==========
    const BANK_NAME = 'BCA';
    const BANK_ACCOUNT = '1234567890';
    const ACCOUNT_NAME = 'NAMA PEMILIK REKENING';
    
    // ========== TEMPLATE SETTINGS ==========
    const DEFAULT_TEMPLATE = 'royal-elegance';
    
    /**
     * Initialize configuration
     */
    public static function init() {
        // Set timezone
        date_default_timezone_set(self::TIMEZONE);
        
        // Error reporting
        if (self::DEBUG_MODE) {
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
            ini_set('display_startup_errors', 1);
        } else {
            error_reporting(0);
            ini_set('display_errors', 0);
        }
        
        // Set upload limits
        ini_set('upload_max_filesize', '10M');
        ini_set('post_max_size', '10M');
        ini_set('max_execution_time', '300');
        
        // Start session
        if (session_status() == PHP_SESSION_NONE) {
            session_start([
                'cookie_lifetime' => 86400,
                'cookie_httponly' => true,
                'cookie_secure' => false,
                'cookie_samesite' => 'Lax'
            ]);
        }
        
        // Auto-create uploads directory
        self::createUploadsDirectory();
    }
    
    /**
     * Get database connection
     */
    public static function getConnection() {
        try {
            $dsn = "mysql:host=" . self::DB_HOST . ";port=" . self::DB_PORT . ";dbname=" . self::DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, self::DB_USER, self::DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            
            return $pdo;
            
        } catch (PDOException $e) {
            die("<h3>Database Connection Error</h3>
                <p><strong>Error:</strong> " . $e->getMessage() . "</p>
                <p><strong>Current Config:</strong></p>
                <ul>
                    <li>Host: " . self::DB_HOST . "</li>
                    <li>Port: " . self::DB_PORT . "</li>
                    <li>Database: " . self::DB_NAME . "</li>
                    <li>User: " . self::DB_USER . "</li>
                    <li>Password: " . (self::DB_PASS ? '***' : '(empty)') . "</li>
                </ul>
                <p><a href='test-xampp.php'>Test Connection</a> | 
                <a href='setup-database.php'>Setup Database</a></p>");
        }
    }
    
    /**
     * Create uploads directory
     */
    private static function createUploadsDirectory() {
        $upload_path = __DIR__ . '/../uploads/';
        
        if (!file_exists($upload_path)) {
            mkdir($upload_path, 0755, true);
            
            // Subdirectories
            $subdirs = ['photos', 'gallery', 'avatars', 'tmp', 'backup'];
            foreach ($subdirs as $subdir) {
                $dir = $upload_path . $subdir . '/';
                if (!file_exists($dir)) {
                    mkdir($dir, 0755, true);
                }
            }
        }
    }
    
    /**
     * Get base URL
     */
    public static function getBaseUrl($path = '') {
        // Auto-detect base URL
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        $path_dir = dirname($script);
        
        $base_url = $protocol . '://' . $host . $path_dir . '/';
        $base_url = rtrim($base_url, '/') . '/';
        
        if (!empty($path)) {
            $path = ltrim($path, '/');
            return $base_url . $path;
        }
        
        return $base_url;
    }
}

// Initialize
DatabaseConfig::init();

// Global function
function base_url($path = '') {
    return DatabaseConfig::getBaseUrl($path);
}

// Define constants
define('BASE_URL', DatabaseConfig::getBaseUrl());
define('SITE_NAME', DatabaseConfig::SITE_NAME);
?>