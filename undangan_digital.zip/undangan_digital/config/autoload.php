<?php
// config/autoload.php - Autoloader untuk classes

spl_autoload_register(function ($class_name) {
    // List of directories to search
    $directories = [
        __DIR__ . '/../includes/classes/',
        __DIR__ . '/../includes/',
        __DIR__ . '/../admin/classes/',
        __DIR__ . '/../'
    ];
    
    // Convert class name to file name
    $class_file = str_replace('\\', '/', $class_name) . '.php';
    
    foreach ($directories as $directory) {
        $file = $directory . $class_file;
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
    
    // Jika class tidak ditemukan di DEBUG mode
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        error_log("Class not found: {$class_name}");
    }
});

// Load core classes jika ada
$core_classes = ['Database', 'Auth', 'User', 'Template'];
foreach ($core_classes as $class) {
    $class_file = __DIR__ . "/../includes/classes/{$class}.php";
    if (file_exists($class_file)) {
        require_once $class_file;
    }
}
?>