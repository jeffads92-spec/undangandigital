<?php
// includes/functions.php

/**
 * Global helper functions untuk website undangan
 */

/**
 * Redirect dengan pesan flash
 */
function redirect($url, $message = null, $type = 'success') {
    if ($message) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    header('Location: ' . base_url($url));
    exit;
}

/**
 * Get flash message
 */
function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        
        return [
            'message' => $message,
            'type' => $type
        ];
    }
    return null;
}

/**
 * Format currency Indonesia
 */
function format_currency($amount) {
    return 'Rp ' . number_format($amount, 0, ',', '.');
}

/**
 * Format tanggal Indonesia
 */
function format_date($date, $format = 'd F Y') {
    $english_months = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
    $indonesian_months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                         'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    
    $formatted = date($format, strtotime($date));
    return str_replace($english_months, $indonesian_months, $formatted);
}

/**
 * Get days until wedding
 */
function days_until_wedding($wedding_date) {
    $now = new DateTime();
    $wedding = new DateTime($wedding_date);
    
    if ($now > $wedding) {
        return 0; // Wedding already passed
    }
    
    $interval = $now->diff($wedding);
    return $interval->days;
}

/**
 * Generate random string
 */
function generate_random_string($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $random_string = '';
    
    for ($i = 0; $i < $length; $i++) {
        $random_string .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $random_string;
}

/**
 * Generate QR code data untuk testing
 */
function generate_test_qr_data($amount = 0, $description = 'Wedding Gift') {
    $data = [
        'amount' => $amount,
        'description' => $description,
        'timestamp' => time(),
        'test_mode' => true
    ];
    
    return json_encode($data);
}

/**
 * Simulate WhatsApp sending
 */
function simulate_whatsapp_send($phone, $message) {
    if (config('testing.mock_whatsapp')) {
        // Log untuk testing
        error_log("WhatsApp SIMULATION to $phone: " . substr($message, 0, 100) . "...");
        return true;
    }
    
    // Untuk production, implementasi real API disini
    return false;
}

/**
 * Validate email
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate phone number
 */
function validate_phone($phone) {
    // Format Indonesia: 0812-3456-7890 atau +62812-3456-7890
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    
    // Cek apakah diawali dengan 0 atau +62
    if (preg_match('/^(0|62|\+62)/', $phone)) {
        return true;
    }
    
    return false;
}

/**
 * Sanitize input
 */
function sanitize_input($input) {
    if (is_array($input)) {
        return array_map('sanitize_input', $input);
    }
    
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Get client IP
 */
function get_client_ip() {
    $ipaddress = '';
    
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if (isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if (isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    
    return $ipaddress;
}

/**
 * Get current URL
 */
function current_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Get template path
 */
function template_path($template_name = null) {
    if (!$template_name) {
        $template_name = config('site.default_template') ?? 'royal-elegance';
    }
    
    return __DIR__ . '/../templates/' . $template_name . '/';
}

/**
 * Include template file
 */
function template_include($file, $data = []) {
    $template_path = template_path();
    $file_path = $template_path . $file;
    
    if (file_exists($file_path)) {
        extract($data);
        include $file_path;
    } else {
        echo "Template file not found: " . basename($file);
    }
}

/**
 * Load JSON data
 */
function load_json_data($file) {
    if (file_exists($file)) {
        $json = file_get_contents($file);
        return json_decode($json, true);
    }
    
    return [];
}

/**
 * Save JSON data
 */
function save_json_data($file, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($file, $json);
}

/**
 * Create pagination
 */
function paginate($total_items, $current_page, $per_page, $url_pattern) {
    $total_pages = ceil($total_items / $per_page);
    
    $pagination = [
        'total_items' => $total_items,
        'current_page' => $current_page,
        'per_page' => $per_page,
        'total_pages' => $total_pages,
        'has_previous' => $current_page > 1,
        'has_next' => $current_page < $total_pages,
        'previous_page' => max(1, $current_page - 1),
        'next_page' => min($total_pages, $current_page + 1)
    ];
    
    // Generate page numbers
    $pages = [];
    $max_pages_to_show = 5;
    
    $start_page = max(1, $current_page - floor($max_pages_to_show / 2));
    $end_page = min($total_pages, $start_page + $max_pages_to_show - 1);
    
    if ($end_page - $start_page < $max_pages_to_show - 1) {
        $start_page = max(1, $end_page - $max_pages_to_show + 1);
    }
    
    for ($i = $start_page; $i <= $end_page; $i++) {
        $pages[] = [
            'number' => $i,
            'url' => str_replace('{page}', $i, $url_pattern),
            'is_current' => $i == $current_page
        ];
    }
    
    $pagination['pages'] = $pages;
    
    return $pagination;
}
?>