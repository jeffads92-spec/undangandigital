<?php
// test-simple.php - Simple database test
echo "<h1>Testing Database Connection</h1>";

// Include config
require_once 'config/database.php';

echo "<h2>Config Test:</h2>";
echo "Database Host: " . DatabaseConfig::DB_HOST . "<br>";
echo "Database Name: " . DatabaseConfig::DB_NAME . "<br>";
echo "Database User: " . DatabaseConfig::DB_USER . "<br>";
echo "Debug Mode: " . (DatabaseConfig::DEBUG_MODE ? 'ON' : 'OFF') . "<br>";
echo "Localhost: " . (DatabaseConfig::isLocalhost() ? 'Yes' : 'No') . "<br>";

echo "<h2>Database Connection Test:</h2>";
try {
    $conn = DatabaseConfig::getConnection();
    echo "<p style='color: green; font-weight: bold;'>✓ Database connected successfully!</p>";
    
    // Test query
    $stmt = $conn->query("SELECT 1 as test");
    $result = $stmt->fetch();
    
    if ($result) {
        echo "✓ Basic query test passed<br>";
    }
    
    // Check tables
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "✓ Found " . count($tables) . " table(s)<br>";
    
    if (count($tables) > 0) {
        echo "<h3>Tables in database:</h3>";
        echo "<ul>";
        foreach ($tables as $table) {
            echo "<li>$table</li>";
        }
        echo "</ul>";
    } else {
        echo "<p style='color: orange;'>Database exists but no tables found.</p>";
        echo "<p>You need to import the database schema.</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red; font-weight: bold;'>✗ Database connection failed!</p>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    
    echo "<h3>Troubleshooting Steps:</h3>";
    echo "<ol>";
    echo "<li>Open XAMPP Control Panel</li>";
    echo "<li>Start Apache and MySQL services</li>";
    echo "<li>Open phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a></li>";
    echo "<li>Create database: <code>CREATE DATABASE undangan_digital</code></li>";
    echo "<li>Or check if database already exists</li>";
    echo "</ol>";
    
    echo "<h3>Current XAMPP Defaults:</h3>";
    echo "Username: root<br>";
    echo "Password: (empty)<br>";
    echo "Host: localhost<br>";
    echo "Port: 3306<br>";
}

echo "<h2>File Permissions Test:</h2>";
$upload_path = DatabaseConfig::getUploadPath();
echo "Upload Path: " . $upload_path . "<br>";
echo "Exists: " . (file_exists($upload_path) ? 'Yes' : 'No') . "<br>";
echo "Writable: " . (is_writable($upload_path) ? 'Yes' : 'No') . "<br>";

// Test write
if (file_exists($upload_path)) {
    $test_file = $upload_path . 'test.txt';
    if (file_put_contents($test_file, 'Test write at ' . date('Y-m-d H:i:s'))) {
        echo "✓ Can write to uploads directory<br>";
        unlink($test_file);
    } else {
        echo "✗ Cannot write to uploads directory<br>";
    }
} else {
    echo "✗ Uploads directory not found<br>";
}

echo "<h2>PHP Info:</h2>";
echo "PHP Version: " . PHP_VERSION . "<br>";
echo "PDO MySQL: " . (extension_loaded('pdo_mysql') ? 'Enabled ✓' : 'Disabled ✗') . "<br>";
echo "MySQLi: " . (extension_loaded('mysqli') ? 'Enabled ✓' : 'Disabled ✗') . "<br>";
echo "GD Library: " . (extension_loaded('gd') ? 'Enabled ✓' : 'Disabled ✗') . "<br>";
echo "JSON: " . (extension_loaded('json') ? 'Enabled ✓' : 'Disabled ✗') . "<br>";

echo "<hr>";
echo "<h2>Quick Fixes:</h2>";
echo "<p>If database doesn't exist:</p>";
echo "<pre>";
echo "1. Open: http://localhost/phpmyadmin\n";
echo "2. Click 'New' on left sidebar\n";
echo "3. Database name: undangan_digital\n";
echo "4. Collation: utf8mb4_unicode_ci\n";
echo "5. Click Create\n";
echo "</pre>";

echo "<p>If you need to change config:</p>";
echo "<pre>";
echo "Edit: config/database.php\n";
echo "Change:\n";
echo "const DB_NAME = 'your_database_name';\n";
echo "const DB_USER = 'your_username';\n";
echo "const DB_PASS = 'your_password';\n";
echo "</pre>";

echo "<hr>";
echo "<a href='index.php'>← Back to Homepage</a> | ";
echo "<a href='http://localhost/phpmyadmin' target='_blank'>Open phpMyAdmin</a>";
?>