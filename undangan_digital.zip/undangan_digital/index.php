<?php
/**
 * WEDDING DIGITAL PREMIUM - MAIN ROUTER
 * Fitur: 3 Template, Admin Kompleks, Music Player, QRIS & WhatsApp Gratis
 */

// ========== CONFIGURATION ==========
require_once 'config/database.php';

// ========== ERROR HANDLING ==========
// JANGAN definisikan ulang constants yang sudah ada di config/database.php
// HAPUS baris ini jika ada:
// define('BASE_URL', $base_url);
// define('SITE_NAME', 'Undangan Digital Premium');

// ========== SESSION START ==========
if (session_status() == PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400,
        'cookie_httponly' => true,
        'cookie_secure' => false,
        'cookie_samesite' => 'Lax'
    ]);
}

// ========== DATABASE CONNECTION ==========
try {
    $db = DatabaseConfig::getConnection();
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// ========== GET ACTIVE TEMPLATE ==========
$template = DatabaseConfig::DEFAULT_TEMPLATE;
try {
    $stmt = $db->prepare("SELECT template_name FROM template_settings WHERE is_active = 1 LIMIT 1");
    $stmt->execute();
    $active_template = $stmt->fetch();
    
    if ($active_template && !empty($active_template['template_name'])) {
        $template = $active_template['template_name'];
    }
} catch (Exception $e) {
    // Use default template if error
    if (DatabaseConfig::DEBUG_MODE) {
        error_log("Template selection error: " . $e->getMessage());
    }
}

// ========== GET WEDDING SETTINGS ==========
$wedding_data = [];
$couple_data = [];
$template_settings = [];

try {
    // Get wedding info
    $stmt = $db->query("SELECT * FROM weddings WHERE is_active = 1 LIMIT 1");
    $wedding_data = $stmt->fetch() ?: [];
    
    // Get couple info
    $stmt = $db->query("SELECT * FROM couples LIMIT 1");
    $couple_data = $stmt->fetch() ?: [];
    
    // Get template settings
    $stmt = $db->prepare("SELECT * FROM template_settings WHERE template_name = ? AND is_active = 1");
    $stmt->execute([$template]);
    $template_settings = $stmt->fetch() ?: [];
    
    // Decode JSON fields
    if (!empty($template_settings['colors'])) {
        $template_settings['colors'] = json_decode($template_settings['colors'], true);
    }
    if (!empty($template_settings['fonts'])) {
        $template_settings['fonts'] = json_decode($template_settings['fonts'], true);
    }
    
} catch (Exception $e) {
    // Fallback data untuk testing
    if (DatabaseConfig::DEBUG_MODE) {
        error_log("Database query error: " . $e->getMessage());
    }
    
    $wedding_data = [
        'title' => 'Undangan Digital Premium',
        'couple_name' => 'John & Jane',
        'wedding_date' => date('Y-m-d', strtotime('+30 days')),
        'wedding_time' => '14:00:00',
        'venue' => 'Grand Ballroom Hotel Indonesia',
        'music' => 'assets/audio/wedding-song.mp3'
    ];
    
    $couple_data = [
        'groom_name' => 'John',
        'groom_photo' => 'assets/images/groom.jpg',
        'bride_name' => 'Jane',
        'bride_photo' => 'assets/images/bride.jpg',
        'groom_bio' => 'Putra pertama dari keluarga...',
        'bride_bio' => 'Putri kedua dari keluarga...'
    ];
    
    $template_settings = [
        'colors' => [
            'primary' => '#8B4513',
            'secondary' => '#D4AF37',
            'accent' => '#C19A6B'
        ],
        'fonts' => [
            'heading' => 'Playfair Display',
            'body' => 'Crimson Text'
        ]
    ];
}

// ========== ROUTING SYSTEM ==========
$page = $_GET['page'] ?? 'home';
$allowed_pages = ['home', 'couple', 'events', 'gallery', 'rsvp', 'gifts', 'messages'];

// Clean page parameter
$page = strtolower($page);
$page = preg_replace('/[^a-z]/', '', $page);

if (!in_array($page, $allowed_pages)) {
    $page = 'home';
}

// ========== LOAD TEMPLATE ==========
$template_path = "templates/{$template}/";
$page_file = $template_path . "pages/{$page}.php";
$header_file = $template_path . "partials/header.php";
$footer_file = $template_path . "partials/footer.php";

// Check if template files exist
if (!file_exists($page_file)) {
    // Fallback ke home jika page tidak ada
    $page_file = $template_path . "pages/home.php";
    $page = 'home';
}

// Prepare data for template
$data = [
    'base_url' => base_url(), // Gunakan function base_url() dari config
    'site_name' => SITE_NAME, // Sudah didefinisikan di config
    'page' => $page,
    'template' => $template,
    'wedding' => $wedding_data,
    'couple' => $couple_data,
    'template_settings' => $template_settings,
    'debug_mode' => true // Untuk localhost
];

// Extract data untuk digunakan di template
extract($data);

// ========== RENDER PAGE ==========
try {
    // Include header jika ada
    if (file_exists($header_file)) {
        include $header_file;
    } else {
        // Fallback header sederhana
        ?>
        <!DOCTYPE html>
        <html lang="id">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?= htmlspecialchars($wedding['title'] ?? SITE_NAME) ?></title>
            <link rel="stylesheet" href="<?= base_url("assets/css/{$template}/main.css") ?>">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Crimson+Text:wght@400;600&display=swap" rel="stylesheet">
            <style>
                :root {
                    --primary-color: <?= $template_settings['colors']['primary'] ?? '#8B4513' ?>;
                    --secondary-color: <?= $template_settings['colors']['secondary'] ?? '#D4AF37' ?>;
                    --accent-color: <?= $template_settings['colors']['accent'] ?? '#C19A6B' ?>;
                    --font-heading: '<?= $template_settings['fonts']['heading'] ?? 'Playfair Display' ?>', serif;
                    --font-body: '<?= $template_settings['fonts']['body'] ?? 'Crimson Text' ?>', serif;
                }
            </style>
        </head>
        <body class="<?= $template ?>">
        <?php
    }
    
    // Include page content
    if (file_exists($page_file)) {
        include $page_file;
    } else {
        echo "<div style='padding: 50px; text-align: center;'>";
        echo "<h2>Halaman Tidak Ditemukan</h2>";
        echo "<p>File template untuk halaman <strong>{$page}</strong> tidak ditemukan.</p>";
        echo "<p>Template path: {$template_path}</p>";
        echo "<a href='" . base_url() . "'>Kembali ke Beranda</a>";
        echo "</div>";
    }
    
    // Include footer jika ada
    if (file_exists($footer_file)) {
        include $footer_file;
    } else {
        // Fallback footer
        ?>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(document).ready(function() {
                // Simple audio player
                var audio = new Audio('<?= base_url($wedding['music'] ?? 'assets/audio/wedding.mp3') ?>');
                audio.loop = true;
                
                // Auto play dengan interaksi user
                $(document).one('click', function() {
                    audio.play().catch(function(e) {
                        console.log("Audio play failed:", e);
                    });
                });
                
                // Navigation
                $('a[href^="#"]').on('click', function(e) {
                    e.preventDefault();
                    var target = $(this).attr('href');
                    if (target === '#') return;
                    
                    $('html, body').animate({
                        scrollTop: $(target).offset().top - 80
                    }, 500);
                });
            });
        </script>
        </body>
        </html>
        <?php
    }
    
} catch (Exception $e) {
    // Error handling
    echo "<h2>Template Rendering Error</h2>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<p>File: " . htmlspecialchars($e->getFile()) . " on line " . $e->getLine() . "</p>";
    
    if (DatabaseConfig::DEBUG_MODE) {
        echo "<h3>Debug Info:</h3>";
        echo "<pre>";
        echo "Template: {$template}\n";
        echo "Page: {$page}\n";
        echo "Page File: {$page_file}\n";
        echo "Exists: " . (file_exists($page_file) ? 'Yes' : 'No') . "\n";
        echo "Base URL: " . base_url() . "\n";
        echo "</pre>";
    }
}

// Debug info untuk localhost
if (isset($data['debug_mode']) && $data['debug_mode']) {
    echo "<!-- DEBUG: Page = {$page}, Template = {$template} -->\n";
    echo "<!-- DEBUG: Database = " . DatabaseConfig::DB_NAME . " -->\n";
}
?>