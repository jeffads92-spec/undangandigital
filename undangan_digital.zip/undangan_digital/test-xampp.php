<?php
echo "<h1>XAMPP Connection Test</h1>";

// Test different configurations
$configs = [
    ['host' => 'localhost', 'user' => 'root', 'pass' => '', 'desc' => 'XAMPP Default (root, no password)'],
    ['host' => '127.0.0.1', 'user' => 'root', 'pass' => '', 'desc' => '127.0.0.1 (root, no password)'],
    ['host' => 'localhost', 'user' => 'admin', 'pass' => 'admin', 'desc' => 'Custom (admin, admin)'],
    ['host' => 'localhost', 'user' => 'root', 'pass' => 'root', 'desc' => 'Root with password root'],
];

foreach ($configs as $config) {
    echo "<h3>Testing: {$config['desc']}</h3>";
    
    try {
        $dsn = "mysql:host={$config['host']};port=3306;charset=utf8mb4";
        $pdo = new PDO($dsn, $config['user'], $config['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        echo "<p style='color: green;'>✓ Connected successfully!</p>";
        
        // Try to create database
        $pdo->exec("CREATE DATABASE IF NOT EXISTS undangan_digital");
        echo "<p style='color: green;'>✓ Database created/checked</p>";
        
        // Show databases
        $stmt = $pdo->query("SHOW DATABASES");
        $dbs = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo "<p>Available databases: " . implode(', ', $dbs) . "</p>";
        
    } catch (PDOException $e) {
        echo "<p style='color: red;'>✗ Failed: " . $e->getMessage() . "</p>";
    }
    
    echo "<hr>";
}

echo "<h2>PHP Configuration:</h2>";
echo "PHP Version: " . PHP_VERSION . "<br>";
echo "PDO MySQL: " . (extension_loaded('pdo_mysql') ? 'Enabled ✓' : 'Disabled ✗') . "<br>";

echo "<h2>Next Steps:</h2>";
echo "<ol>";
echo "<li>Use the configuration that worked above</li>";
echo "<li>Update config/database.php with correct credentials</li>";
echo "<li>Run the installer: <a href='installer/'>http://localhost/undangandigital/installer/</a></li>";
echo "</ol>";
?>