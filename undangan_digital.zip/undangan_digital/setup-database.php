<?php
echo "<h1>Auto Setup Database</h1>";

// Try to connect with default XAMPP credentials
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'undangan_digital';

try {
    // Connect without database first
    $dsn = "mysql:host=$host;port=3306;charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    echo "<p style='color: green;'>✓ Connected to MySQL server</p>";
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "<p style='color: green;'>✓ Database '$dbname' created/checked</p>";
    
    // Use database
    $pdo->exec("USE `$dbname`");
    
    // Create tables
    $tables_sql = [
        "CREATE TABLE IF NOT EXISTS `weddings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `couple_name` varchar(200) NOT NULL,
            `wedding_date` datetime NOT NULL,
            `venue` text NOT NULL,
            `theme` varchar(50) DEFAULT 'royal-elegance',
            `is_active` tinyint(1) DEFAULT 1,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS `couples` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `groom_name` varchar(100) NOT NULL,
            `bride_name` varchar(100) NOT NULL,
            `groom_photo` varchar(255) DEFAULT NULL,
            `bride_photo` varchar(255) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",
        
        "CREATE TABLE IF NOT EXISTS `template_settings` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `template_name` varchar(50) NOT NULL,
            `colors` text DEFAULT NULL,
            `fonts` text DEFAULT NULL,
            `is_active` tinyint(1) DEFAULT 1,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
    ];
    
    foreach ($tables_sql as $sql) {
        $pdo->exec($sql);
    }
    
    echo "<p style='color: green;'>✓ Basic tables created</p>";
    
    // Insert sample data
    $pdo->exec("INSERT IGNORE INTO weddings (couple_name, wedding_date, venue, theme) 
                VALUES ('John & Jane', DATE_ADD(NOW(), INTERVAL 30 DAY), 'Grand Ballroom Hotel', 'royal-elegance')");
    
    $pdo->exec("INSERT IGNORE INTO couples (groom_name, bride_name) 
                VALUES ('John', 'Jane')");
    
    $pdo->exec("INSERT IGNORE INTO template_settings (template_name, colors, fonts) VALUES
                ('royal-elegance', '{\"primary\":\"#8B4513\",\"secondary\":\"#D4AF37\"}', '{\"heading\":\"Playfair Display\",\"body\":\"Crimson Text\"}'),
                ('classic-romance', '{\"primary\":\"#C2185B\",\"secondary\":\"#F8BBD0\"}', '{\"heading\":\"Great Vibes\",\"body\":\"Dancing Script\"}')");
    
    echo "<p style='color: green;'>✓ Sample data inserted</p>";
    
    // Check what we have
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<h3>Database Setup Complete!</h3>";
    echo "<p>Tables created: " . count($tables) . "</p>";
    echo "<ul>";
    foreach ($tables as $table) {
        echo "<li>$table</li>";
    }
    echo "</ul>";
    
    echo "<p><a href='index.php' style='color: green; font-weight: bold;'>→ Go to Website</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
    
    echo "<h3>Manual Setup:</h3>";
    echo "<ol>";
    echo "<li>Open phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a></li>";
    echo "<li>Login with: username 'root', password (empty)</li>";
    echo "<li>Create database: <code>CREATE DATABASE undangan_digital</code></li>";
    echo "<li>Or use the installer: <a href='installer/'>http://localhost/undangandigital/installer/</a></li>";
    echo "</ol>";
}
?>