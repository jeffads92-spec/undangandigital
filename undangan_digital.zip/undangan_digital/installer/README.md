# Auto Installer - Undangan Digital

## Overview
Auto installer system untuk website undangan digital dengan fitur lengkap. Support instalasi via web wizard dan command line.

## Installation Methods

### 1. Web Installer (Recommended)
1. Upload semua file ke server
2. Buka: `http://yourdomain.com/installer/`
3. Ikuti wizard step-by-step
4. Hapus folder installer setelah selesai

### 2. Command Line Installer
```bash
# Berikan permission executable
chmod +x installer/auto-install.sh

# Jalankan installer
cd installer
./auto-install.sh

# Atau dengan parameter
./auto-install.sh --db-host=localhost --db-name=undangan --admin-user=admin