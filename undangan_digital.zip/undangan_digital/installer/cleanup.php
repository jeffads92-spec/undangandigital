<?php
/**
 * Auto Cleanup Script
 * Run this after installation to remove installer files
 */

session_start();

// Only allow access if installation is complete
if (!file_exists('../config/installed.lock')) {
    die('Installation not completed yet.');
}

// Check if cleanup was already done
if (file_exists('../config/cleanup.lock')) {
    die('Cleanup already performed.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $confirmed = $_POST['confirm'] ?? false;
    
    if ($confirmed) {
        performCleanup();
    }
}

function performCleanup() {
    $files_to_delete = [
        __DIR__ . '/index.php',
        __DIR__ . '/cleanup.php',
        __DIR__ . '/database/schema.sql',
        __DIR__ . '/database/sample_data.sql'
    ];
    
    $errors = [];
    
    foreach ($files_to_delete as $file) {
        if (file_exists($file)) {
            if (!unlink($file)) {
                $errors[] = "Failed to delete: " . basename($file);
            }
        }
    }
    
    // Try to remove installer directory
    if (count(scandir(__DIR__)) <= 2) { // Directory is empty (only . and ..)
        if (!rmdir(__DIR__)) {
            $errors[] = "Failed to remove installer directory";
        }
    }
    
    if (empty($errors)) {
        file_put_contents('../config/cleanup.lock', date('Y-m-d H:i:s'));
        
        // Redirect to homepage
        header('Location: ../');
        exit;
    } else {
        return ['success' => false, 'errors' => $errors];
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cleanup Installer - Undangan Digital</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .cleanup-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 600px;
            padding: 40px;
            text-align: center;
        }

        .cleanup-icon {
            font-size: 4rem;
            color: #dc3545;
            margin-bottom: 20px;
        }

        h1 {
            color: #333;
            margin-bottom: 15px;
        }

        p {
            color: #666;
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .warning-box {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
            text-align: left;
        }

        .warning-box h3 {
            color: #856404;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .warning-box ul {
            margin-left: 20px;
            color: #856404;
        }

        .warning-box li {
            margin: 8px 0;
        }

        .files-list {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            text-align: left;
        }

        .files-list h4 {
            color: #333;
            margin-bottom: 10px;
        }

        .file-item {
            padding: 8px 0;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .file-item:last-child {
            border-bottom: none;
        }

        .file-item i {
            color: #6c757d;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin: 10px;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(220, 53, 69, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .checkbox {
            margin: 20px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .checkbox input {
            width: 18px;
            height: 18px;
        }

        .checkbox label {
            color: #333;
            font-weight: 500;
        }

        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: left;
        }

        .alert-error {
            background: #fee;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        .alert-success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
    </style>
</head>
<body>
    <div class="cleanup-container">
        <div class="cleanup-icon">
            <i class="fas fa-trash-alt"></i>
        </div>
        
        <h1>Cleanup Installer Files</h1>
        <p>Instalasi telah selesai. Untuk keamanan sistem, hapus semua file installer dari server.</p>
        
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($result)): ?>
            <?php if ($result['success']): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <strong>Berhasil!</strong> Semua file installer telah dihapus. Anda akan dialihkan ke halaman utama.
                </div>
            <?php else: ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <strong>Terjadi kesalahan:</strong>
                    <ul>
                        <?php foreach ($result['errors'] as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <div class="warning-box">
            <h3><i class="fas fa-exclamation-triangle"></i> PERINGATAN</h3>
            <p>File-file berikut akan dihapus secara permanen:</p>
            <ul>
                <li>File installer wizard</li>
                <li>File skema database</li>
                <li>File sample data</li>
                <li>Direktori installer (jika kosong)</li>
            </ul>
            <p><strong>Tindakan ini tidak dapat dibatalkan!</strong> Pastikan Anda telah:</p>
            <ul>
                <li>Mencatat informasi login admin</li>
                <li>Menguji website berjalan dengan baik</li>
                <li>Mem-backup database jika diperlukan</li>
            </ul>
        </div>
        
        <div class="files-list">
            <h4>File yang akan dihapus:</h4>
            <div class="file-item">
                <i class="fas fa-file-code"></i>
                <span>installer/index.php</span>
            </div>
            <div class="file-item">
                <i class="fas fa-file-code"></i>
                <span>installer/cleanup.php</span>
            </div>
            <div class="file-item">
                <i class="fas fa-database"></i>
                <span>installer/database/schema.sql</span>
            </div>
            <div class="file-item">
                <i class="fas fa-database"></i>
                <span>installer/database/sample_data.sql</span>
            </div>
        </div>
        
        <form method="POST" onsubmit="return confirmCleanup()">
            <div class="checkbox">
                <input type="checkbox" id="confirm" name="confirm" required>
                <label for="confirm">Saya memahami konsekuensi dan ingin menghapus file installer</label>
            </div>
            
            <div>
                <a href="../" class="btn btn-secondary">
                    <i class="fas fa-home"></i> Kembali ke Website
                </a>
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-trash-alt"></i> Hapus Installer
                </button>
            </div>
        </form>
    </div>
    
    <script>
        function confirmCleanup() {
            return confirm('APAKAH ANDA YAKIN?\n\nFile installer akan dihapus permanen. Pastikan Anda telah mencatat semua informasi penting.');
        }
    </script>
</body>
</html>