-- Undangan Digital Database Schema
-- Version: 1.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Table structure for table `admins`
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('superadmin','admin','editor') DEFAULT 'admin',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` datetime DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `weddings`
CREATE TABLE `weddings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `couple_name` varchar(200) NOT NULL,
  `wedding_date` datetime NOT NULL,
  `venue` text NOT NULL,
  `venue_maps` text DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `theme` varchar(50) DEFAULT 'royal-elegance',
  `music` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `couples`
CREATE TABLE `couples` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groom_name` varchar(100) NOT NULL,
  `groom_nickname` varchar(50) DEFAULT NULL,
  `groom_father` varchar(100) DEFAULT NULL,
  `groom_mother` varchar(100) DEFAULT NULL,
  `groom_photo` varchar(255) DEFAULT NULL,
  `groom_bio` text DEFAULT NULL,
  `groom_instagram` varchar(100) DEFAULT NULL,
  `groom_whatsapp` varchar(20) DEFAULT NULL,
  `bride_name` varchar(100) NOT NULL,
  `bride_nickname` varchar(50) DEFAULT NULL,
  `bride_father` varchar(100) DEFAULT NULL,
  `bride_mother` varchar(100) DEFAULT NULL,
  `bride_photo` varchar(255) DEFAULT NULL,
  `bride_bio` text DEFAULT NULL,
  `bride_instagram` varchar(100) DEFAULT NULL,
  `bride_whatsapp` varchar(20) DEFAULT NULL,
  `love_story` text DEFAULT NULL COMMENT 'JSON array of love story events',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `events`
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(50) NOT NULL COMMENT 'akad, resepsi, etc',
  `event_name` varchar(200) DEFAULT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `venue` text NOT NULL,
  `venue_maps` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `dress_code` varchar(100) DEFAULT NULL,
  `transportation` text DEFAULT NULL,
  `icon` varchar(50) DEFAULT 'fas fa-heart',
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `guests`
CREATE TABLE `guests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invitation_code` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `guest_group` varchar(50) DEFAULT NULL COMMENT 'family, friends, colleagues, etc',
  `guest_count` int(11) DEFAULT 1,
  `attendance_status` enum('pending','confirmed','declined','maybe') DEFAULT 'pending',
  `attended` tinyint(1) DEFAULT 0,
  `message` text DEFAULT NULL,
  `receive_updates` tinyint(1) DEFAULT 1,
  `whatsapp_sent` tinyint(1) DEFAULT 0,
  `last_reminder` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `invitation_code` (`invitation_code`),
  KEY `phone` (`phone`),
  KEY `attendance_status` (`attendance_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `payments`
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id` int(11) DEFAULT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL COMMENT 'bca, mandiri, bri, gopay, ovo, dana, etc',
  `payment_status` enum('pending','processing','success','failed','expired') DEFAULT 'pending',
  `qr_code` text DEFAULT NULL,
  `qr_expiry` datetime DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `account_name` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `guest_id` (`guest_id`),
  KEY `payment_status` (`payment_status`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `messages`
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `relation` varchar(50) DEFAULT NULL COMMENT 'family, friend, colleague, etc',
  `message` text NOT NULL,
  `privacy` enum('public','private') DEFAULT 'public',
  `like_count` int(11) DEFAULT 0,
  `is_approved` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `guest_id` (`guest_id`),
  KEY `is_approved` (`is_approved`),
  FULLTEXT KEY `message` (`message`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `message_likes`
CREATE TABLE `message_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_like` (`message_id`,`guest_id`,`ip_address`),
  KEY `message_id` (`message_id`),
  CONSTRAINT `message_likes_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `gallery`
CREATE TABLE `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL COMMENT 'prewedding, engagement, family, etc',
  `image_url` varchar(255) NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  `caption` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `videos`
CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `thumbnail_url` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `bank_accounts`
CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(100) NOT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `qr_code` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `display_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_number` (`account_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `ewallets`
CREATE TABLE `ewallets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wallet_name` varchar(50) NOT NULL COMMENT 'gopay, ovo, dana, etc',
  `account_number` varchar(50) NOT NULL,
  `account_name` varchar(100) NOT NULL,
  `qr_code` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `display_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `gift_registry`
CREATE TABLE `gift_registry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `store_link` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_reserved` tinyint(1) DEFAULT 0,
  `reserved_by` int(11) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `template_settings`
CREATE TABLE `template_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(50) NOT NULL,
  `colors` text DEFAULT NULL COMMENT 'JSON color scheme',
  `fonts` text DEFAULT NULL COMMENT 'JSON font settings',
  `custom_css` text DEFAULT NULL,
  `custom_js` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_name` (`template_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `whatsapp_templates`
CREATE TABLE `whatsapp_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) NOT NULL,
  `template_content` text NOT NULL,
  `variables` text DEFAULT NULL COMMENT 'JSON array of variable names',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `whatsapp_messages`
CREATE TABLE `whatsapp_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `guest_id` int(11) DEFAULT NULL,
  `template_name` varchar(100) DEFAULT NULL,
  `message_id` varchar(100) DEFAULT NULL,
  `to_number` varchar(20) NOT NULL,
  `message_content` text NOT NULL,
  `status` enum('pending','sent','delivered','read','failed') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `guest_id` (`guest_id`),
  KEY `status` (`status`),
  KEY `to_number` (`to_number`),
  CONSTRAINT `whatsapp_messages_ibfk_1` FOREIGN KEY (`guest_id`) REFERENCES `guests` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `analytics`
CREATE TABLE `analytics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_views` int(11) DEFAULT 0,
  `unique_visitors` int(11) DEFAULT 0,
  `rsvp_count` int(11) DEFAULT 0,
  `payment_count` int(11) DEFAULT 0,
  `message_count` int(11) DEFAULT 0,
  `date_recorded` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `date_recorded` (`date_recorded`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `visitors`
CREATE TABLE `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `referrer` text DEFAULT NULL,
  `page_visited` varchar(255) DEFAULT NULL,
  `visit_count` int(11) DEFAULT 1,
  `first_visit` datetime DEFAULT current_timestamp(),
  `last_visit` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `ip_address` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `notifications`
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `notification_type` varchar(50) DEFAULT NULL COMMENT 'payment, rsvp, message, system',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `logs`
CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` varchar(50) NOT NULL COMMENT 'login, payment, rsvp, error',
  `description` text NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `data` text DEFAULT NULL COMMENT 'JSON additional data',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `log_type` (`log_type`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `settings`
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(50) DEFAULT 'general',
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table structure for table `migrations`
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `migration_name` varchar(200) NOT NULL,
  `batch` int(11) NOT NULL,
  `executed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `is_public`) VALUES
('site_title', 'Undangan Digital Pernikahan', 'general', 1),
('site_description', 'Website undangan digital pernikahan dengan fitur lengkap', 'general', 1),
('site_keywords', 'undangan digital, wedding, pernikahan, invitation', 'general', 1),
('timezone', 'Asia/Jakarta', 'general', 0),
('currency', 'IDR', 'general', 1),
('whatsapp_enabled', '1', 'feature', 0),
('qris_enabled', '1', 'feature', 0),
('pwa_enabled', '1', 'feature', 0),
('guest_password', '123456', 'security', 0),
('max_guests_per_rsvp', '10', 'validation', 1),
('rsvp_deadline_days', '3', 'validation', 1),
('payment_timeout_minutes', '60', 'payment', 0),
('enable_auto_backup', '1', 'system', 0),
('backup_frequency', 'daily', 'system', 0),
('maintenance_mode', '0', 'system', 1);

-- Insert default WhatsApp templates
INSERT INTO `whatsapp_templates` (`template_name`, `template_content`, `variables`, `is_active`) VALUES
('invitation', 'Assalamualaikum warahmatullahi wabarakatuh\n\n*INVITATION WEDDING*\n\nKepada Yth. {name}\n\nKami mengundang Bapak/Ibu/Saudara/i untuk menghadiri acara pernikahan:\n\n*{groom_name} & {bride_name}*\n\n📅 {date}\n⏰ {time}\n📍 {venue}\n\nMohon konfirmasi kehadiran melalui link: {rsvp_link}\n\nDetail acara: {wedding_link}\n\nMerupakan suatu kehormatan dan kebahagiaan bagi kami apabila Bapak/Ibu/Saudara/i berkenan hadir dan memberikan doa restu.\n\nHormat kami,\nKeluarga Besar {groom_name} & {bride_name}', '[\"name\", \"groom_name\", \"bride_name\", \"date\", \"time\", \"venue\", \"rsvp_link\", \"wedding_link\"]', 1),
('payment_confirmation', 'Halo {name}\n\nTerima kasih telah mengirimkan hadiah untuk pernikahan kami.\n\n📋 *Detail Pembayaran*\nID Transaksi: {transaction_id}\nTanggal: {date}\nJumlah: Rp {amount}\nMetode: {payment_method}\n\nStatus: ✅ Berhasil\n\nTerima kasih atas doa dan hadiahnya. Kami sangat menghargai kebaikan Anda.\n\nSalam hangat,\n{groom_name} & {bride_name}', '[\"name\", \"transaction_id\", \"date\", \"amount\", \"payment_method\", \"groom_name\", \"bride_name\"]', 1),
('rsvp_reminder', 'Halo {name}\n\nMengingatkan untuk konfirmasi kehadiran di pernikahan kami:\n\n📅 {date}\n⏰ {time}\n📍 {venue}\n\nMohon konfirmasi melalui: {rsvp_link}\n\nTerima kasih,\n{groom_name} & {bride_name}', '[\"name\", \"date\", \"time\", \"venue\", \"rsvp_link\", \"groom_name\", \"bride_name\"]', 1);

-- Insert default migration record
INSERT INTO `migrations` (`migration_name`, `batch`) VALUES
('2024_01_01_000000_create_base_tables', 1);

COMMIT;