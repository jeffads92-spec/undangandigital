#!/bin/bash

# Undangan Digital Auto Installer
# Version: 1.0.0

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
DB_HOST="localhost"
DB_PORT="3306"
DB_NAME="undangan_digital"
DB_USER="root"
DB_PASS=""
ADMIN_USER="admin"
ADMIN_PASS="Admin123!"
ADMIN_EMAIL="admin@example.com"
SITE_URL="http://localhost/undangan"
THEME="royal-elegance"

# Banner
echo -e "${BLUE}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║        UNDANGAN DIGITAL AUTO INSTALLER v1.0.0           ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Function to print status
print_status() {
    echo -e "[${GREEN}✓${NC}] $1"
}

print_warning() {
    echo -e "[${YELLOW}!${NC}] $1"
}

print_error() {
    echo -e "[${RED}✗${NC}] $1"
}

# Check requirements
echo -e "\n${BLUE}Checking system requirements...${NC}"

check_php() {
    if command -v php &> /dev/null; then
        PHP_VERSION=$(php -v | head -n1 | cut -d " " -f 2)
        if [[ "$PHP_VERSION" > "7.4.0" ]]; then
            print_status "PHP $PHP_VERSION (OK)"
            return 0
        else
            print_error "PHP 7.4+ required (found $PHP_VERSION)"
            return 1
        fi
    else
        print_error "PHP not found"
        return 1
    fi
}

check_mysql() {
    if command -v mysql &> /dev/null; then
        print_status "MySQL client found"
        return 0
    else
        print_error "MySQL client not found"
        return 1
    fi
}

check_composer() {
    if command -v composer &> /dev/null; then
        print_status "Composer found"
        return 0
    else
        print_warning "Composer not found (optional)"
        return 1
    fi
}

check_git() {
    if command -v git &> /dev/null; then
        print_status "Git found"
        return 0
    else
        print_warning "Git not found (optional)"
        return 1
    fi
}

check_php
check_mysql
check_composer
check_git

# Get installation parameters
echo -e "\n${BLUE}Installation Configuration${NC}"
read -p "Database host [$DB_HOST]: " input_db_host
DB_HOST=${input_db_host:-$DB_HOST}

read -p "Database port [$DB_PORT]: " input_db_port
DB_PORT=${input_db_port:-$DB_PORT}

read -p "Database name [$DB_NAME]: " input_db_name
DB_NAME=${input_db_name:-$DB_NAME}

read -p "Database username [$DB_USER]: " input_db_user
DB_USER=${input_db_user:-$DB_USER}

read -s -p "Database password (hidden): " input_db_pass
DB_PASS=${input_db_pass:-$DB_PASS}
echo

read -p "Admin username [$ADMIN_USER]: " input_admin_user
ADMIN_USER=${input_admin_user:-$ADMIN_USER}

read -s -p "Admin password (min 8 chars) [$ADMIN_PASS]: " input_admin_pass
ADMIN_PASS=${input_admin_pass:-$ADMIN_PASS}
echo

read -p "Admin email [$ADMIN_EMAIL]: " input_admin_email
ADMIN_EMAIL=${input_admin_email:-$ADMIN_EMAIL}

read -p "Site URL [$SITE_URL]: " input_site_url
SITE_URL=${input_site_url:-$SITE_URL}

echo -e "\n${BLUE}Select theme:${NC}"
echo "1) Royal Elegance (Elegant & Minimalist)"
echo "2) Classic Romance (Romantic & Traditional)"
echo "3) Garden Bliss (Natural & Outdoor)"
read -p "Choice [1-3, default: 1]: " theme_choice

case $theme_choice in
    2) THEME="classic-romance" ;;
    3) THEME="garden-bliss" ;;
    *) THEME="royal-elegance" ;;
esac

# Confirm installation
echo -e "\n${YELLOW}Installation Summary:${NC}"
echo "----------------------------------------"
echo "Database: $DB_USER@$DB_HOST:$DB_PORT/$DB_NAME"
echo "Admin: $ADMIN_USER ($ADMIN_EMAIL)"
echo "Site URL: $SITE_URL"
echo "Theme: $THEME"
echo "----------------------------------------"

read -p "Continue with installation? [y/N]: " confirm
if [[ ! $confirm =~ ^[Yy]$ ]]; then
    echo -e "${RED}Installation cancelled.${NC}"
    exit 1
fi

# Start installation
echo -e "\n${BLUE}Starting installation...${NC}"

# Create database
echo -n "Creating database..."
if mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASS" -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null; then
    print_status "Database created"
else
    print_error "Failed to create database"
    exit 1
fi

# Import schema
echo -n "Importing database schema..."
if mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < database/schema.sql 2>/dev/null; then
    print_status "Schema imported"
else
    print_error "Failed to import schema"
    exit 1
fi

# Hash admin password
ADMIN_PASS_HASH=$(php -r "echo password_hash('$ADMIN_PASS', PASSWORD_DEFAULT);")

# Insert admin user
echo -n "Creating admin user..."
mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" <<EOF 2>/dev/null
INSERT INTO admins (username, password, email, full_name, role, is_active, created_at) 
VALUES ('$ADMIN_USER', '$ADMIN_PASS_HASH', '$ADMIN_EMAIL', 'Administrator', 'superadmin', 1, NOW());
EOF

if [ $? -eq 0 ]; then
    print_status "Admin user created"
else
    print_error "Failed to create admin user"
    exit 1
fi

# Create config file
echo -n "Creating configuration file..."
cat > config/database.php <<EOF
<?php
// Database Configuration
define("DB_HOST", "$DB_HOST");
define("DB_PORT", "$DB_PORT");
define("DB_NAME", "$DB_NAME");
define("DB_USER", "$DB_USER");
define("DB_PASS", "$DB_PASS");

// Application Configuration
define("BASE_URL", "$SITE_URL");
define("SITE_NAME", "Undangan Digital");
define("TIMEZONE", "Asia/Jakarta");
define("DEBUG_MODE", false);

// Security
define("ENCRYPTION_KEY", "$(openssl rand -hex 16)");
define("JWT_SECRET", "$(openssl rand -hex 32)");

// File Uploads
define("MAX_UPLOAD_SIZE", 5242880); // 5MB
define("ALLOWED_IMAGE_TYPES", ["image/jpeg", "image/png", "image/gif", "image/webp"]);
define("UPLOAD_PATH", dirname(__DIR__) . "/uploads/");

// Session
ini_set("session.cookie_httponly", 1);
ini_set("session.use_only_cookies", 1);

// Error Reporting
if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
} else {
    error_reporting(0);
    ini_set("display_errors", 0);
}

// Timezone
date_default_timezone_set(TIMEZONE);

// Create database connection
try {
    \$dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    \$conn = new PDO(\$dsn, DB_USER, DB_PASS);
    \$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    \$conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    \$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException \$e) {
    die("Database connection failed: " . \$e->getMessage());
}

// Helper function for base_url
function base_url(\$path = "") {
    return BASE_URL . "/" . ltrim(\$path, "/");
}
?>
EOF

if [ $? -eq 0 ]; then
    print_status "Configuration file created"
else
    print_error "Failed to create configuration file"
    exit 1
fi

# Set file permissions
echo -n "Setting file permissions..."
chmod 755 uploads assets 2>/dev/null
chmod 644 config/database.php 2>/dev/null
print_status "Permissions set"

# Create .htaccess if not exists
if [ ! -f .htaccess ]; then
    echo -n "Creating .htaccess..."
    cat > .htaccess <<'HTACCESS'
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?/$1 [L,QSA]
Options -Indexes
HTACCESS
    print_status ".htaccess created"
fi

# Create installed lock
echo -n "Creating installation lock..."
echo "$(date)" > config/installed.lock
print_status "Installation lock created"

# Install complete
echo -e "\n${GREEN}"
echo "╔══════════════════════════════════════════════════════════╗"
echo "║                INSTALLATION COMPLETE!                   ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "\n${BLUE}Installation Details:${NC}"
echo "----------------------------------------"
echo "Website URL: $SITE_URL"
echo "Admin Panel: $SITE_URL/admin"
echo "Admin Username: $ADMIN_USER"
echo "Admin Password: $ADMIN_PASS"
echo "----------------------------------------"

echo -e "\n${YELLOW}Next Steps:${NC}"
echo "1. Login to admin panel and configure wedding details"
echo "2. Upload photos and customize theme"
echo "3. Import guest list"
echo "4. Configure WhatsApp and QRIS API"
echo "5. Test all features before launch"

echo -e "\n${RED}IMPORTANT SECURITY:${NC}"
echo "1. Remove installer directory: rm -rf installer/"
echo "2. Change admin password immediately"
echo "3. Configure SSL/HTTPS"
echo "4. Set up regular backups"

echo -e "\n${GREEN}Thank you for choosing Undangan Digital!${NC}"